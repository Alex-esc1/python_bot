import config
import telebot

bot = telebot.TeleBot(config.token)

@bot.message_handler(content_types=['text'])
def get_text_messages(message):
  if message.text == "/start":
      bot.send_message(message.from_user.id, "Ты кто такой. Пиши сраный УНП давай. Хочешь заявки?")
  elif "Хочу" in message.text:
      bot.send_message(message.from_user.id, "я тоже много чего хочу. Напиши слово => Пожалуйста")
  elif "1" in message.text:
      bot.send_message(message.from_user.id, "НЕ НАДО МНЕ ТВОЙ УНП, пиши слово => Хочу")
  elif "Пожалуйста" in message.text:
      bot.send_message(message.from_user.id, "А теперь пиши => Да мой господин")
  elif "Да мой господин" in message.text:
      bot.send_message(message.from_user.id, "Молодец. Твой господин устал, заявок не будет :)")
  else:
      bot.send_message(message.from_user.id, "Да блин, напиши => Хочу")
bot.polling(none_stop=True, interval=0)